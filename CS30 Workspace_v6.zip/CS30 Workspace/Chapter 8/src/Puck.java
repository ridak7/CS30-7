
public class Puck extends Disk
{

	private double weight;
	private boolean standard;
	private boolean youth;
	
	private double minStandard = 5;
	private double maxStandard = 5.5;
	private double minYouth = 4;
	private double maxYouth = 4.5;
	
		
	public Puck(double w) 
	{
		super(w, 1.5);
		weight = w;
		
		if (w >= minStandard && w <= maxStandard)
		{
			standard = true;
		}
		else if (w >= minYouth && w <= maxYouth)
		{
			youth = true;
		}
	}
	
	
	public String getDivision()
	{
		if (standard == true)
		{
			return ("The puck is a standard division puck")
		}
		else if(youth == true)
		{
			return ("The puck is a youth division puck")
		}
			
	}

	
	@Override
	public equals()
	{
		
	}
	
	
	@Override
	public toString()
	{
		
	}
	
}
