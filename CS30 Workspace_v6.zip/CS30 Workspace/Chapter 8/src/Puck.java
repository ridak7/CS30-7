
public class Puck extends Disk
{

	private double weight;
	private boolean standard;
	private boolean youth;
	
		
	public Puck(double v, double w) 
	{
		super(v, w);
		weight = w;
	}
	
	
	/*public String getWeight()
	{
		
	}*/
	
	/*public String getDivision()
	{
		
	}*/

	
	public equals()
	{
		@Override
		equals();
		
	}
	
	public Override toString()
	{
		
	}
	
}
